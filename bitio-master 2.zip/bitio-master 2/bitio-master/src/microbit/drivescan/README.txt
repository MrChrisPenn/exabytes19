DRIVESCAN - a package that scans removable drives
